import React, { Component } from 'react';
import { createProduct,getAllCategories,getAllSubCategories } from '../util/APIUtils';
import './NewProduct.css';  
import { Form, Input, Button,notification, Select, Upload, Icon } from 'antd';
const FormItem = Form.Item;
const { Option } = Select;

class NewProduct extends Component {
    constructor(props) {
        super(props);
        this.state = {
            productCode: {
                text: ''
            },
            productName:{
                text:''
            },
            description: {
                text:''
            },
            categoryName:{
                text:''
            },
            categoryId: {
                text:''
            },
            subCategoryName:{
                text:''
            },
            subCategoryId:{
                text:''
            },
            price: {
                number:0
            },
            brand: {
                text:''
            },
            stock: {
                number:0
            },
            image:{
                text:''
            },
            active:{
                Boolean:true
            },
            categories:[],
            category:{
                key:0,
        label: "Please Select Any Category"},
            subCategories:[],
            subCategory:{
                key:0,
        label: "Please Select Any SubCategory"}
        };
        this.handleProductCodeChange = this.handleProductCodeChange.bind(this);
        this.handleProductNameChange = this.handleProductNameChange.bind(this);
        this.handleDescriptionChange = this.handleDescriptionChange.bind(this);
        this.handlePriceChange = this.handlePriceChange.bind(this);
        this.handleBrandChange = this.handleBrandChange.bind(this);
        this.handleStockChange = this.handleStockChange.bind(this);

        this.handleCategoryIdChange = this.handleCategoryIdChange.bind(this);
        this.handleSubCategoryIdChange = this.handleSubCategoryIdChange.bind(this);

        this.handleSubmit = this.handleSubmit.bind(this);
        this.isFormInvalid = this.isFormInvalid.bind(this);
    }


    loadCategoriesList() {
        let promise;
        promise = getAllCategories();
        if(!promise) {
            return;
        }
        this.setState({
            isLoading: true
        });
        promise            
        .then(response => {
            console.log(response);
            const categories = this.state.categories.slice();
            this.setState({
                categories: categories.concat(response),
                isLoading: false
            })
        }).catch(error => {
            this.setState({
                isLoading: false
            })
        });  
        
    }

    
    loadSubCategoriesList(id) {
        let promise;
        promise = getAllSubCategories(id);
        if(!promise) {
            return;
        }
        this.setState({
            isLoading: true
        });
        promise            
        .then(response => {
            console.log(response);
            const subCategories = this.state.subCategories.slice();
            this.setState({
                subCategories: subCategories.concat(response),
                isLoading: false
            })
        }).catch(error => {
            this.setState({
                isLoading: false
            })
        });  
        
    }


    componentDidMount() {
        this.loadCategoriesList();
    }

    handleSubmit(event) {
        event.preventDefault();
        const productData = {
            productCode: this.state.productCode.text,
            productName:this.state.productName.text,
            description: this.state.description.text,
            categoryName:this.state.categoryName.text,
            categoryId: this.state.categoryId.text,
            subCategoryName:this.state.subCategoryName.text,
            subCategoryId:this.state.subCategoryId.text,
            price:this.state.price.number,
            brand: this.state.brand.text,
            stock:this.state.stock.number,
            image:this.state.image.text,
            active:this.state.active.text
        };  

        createProduct(productData)
        .then(response => {
            notification.success({
                message: 'Online Shopping',
                description: "Product created successfully.",
            });
            this.props.history.push("/products");
        }).catch(error => {
            if(error.status === 401) {
                this.props.handleLogout('/login', 'error', 'You have been logged out. Please login create product.');    
            } else {
                notification.error({
                    message: 'Online Shopping',
                    description: error.message || 'Sorry! Something went wrong. Please try again!'
                });              
            }
        });
    }

    validateString = (nameText) => {
        if(nameText.length === 0) {
            return {
                validateStatus: 'error',
                errorMsg: 'Please enter a value!'
            }
        } else {
            return {
                validateStatus: 'success',
                errorMsg: null
            }
        }
    }

    handleProductNameChange(event) {
        const value = event.target.value;
        this.setState({
            productName: {
                text: value,
                ...this.validateString(value)
            }
        });
    }

    handleProductCodeChange(event) {
        const value = event.target.value;
        this.setState({
            productCode: {
                text: value,
                ...this.validateString(value)
            }
        });
    }

    handleBrandChange(event) {
        const value = event.target.value;
        this.setState({
            brand: {
                text: value,
                ...this.validateString(value)
            }
        });
    }

    handleDescriptionChange(event) {
        const value = event.target.value;
        this.setState({
            description: {
                text: value,
                ...this.validateString(value)
            }
        });
        console.log(this.state.description)

    }

    validateAmount = (text) => {
        if (typeof text !== "undefined") {
            var pattern = new RegExp(/^[0-9\b]+$/);
          
            if (!pattern.test(text)) {
                return {
                    validateStatus: 'error',
                    errorMsg: 'Please enter only number.'
                }                    
            }else if(text == 0){
                return {
                    validateStatus: 'error',
                    errorMsg: 'Please enter valid number.'
                }          
            }else {
                return {
                    validateStatus: 'success',
                    errorMsg: null
                }
            }
          }else {
            return {
                validateStatus: 'error',
                errorMsg: 'Please enter valid number.'
            }
        }
    }

    handlePriceChange(event) {
        const target = event.target;
        const inputName = target.name;        
        const inputValue = target.value;
        console.log(inputName+"--"+inputValue)
        this.setState({
            [inputName] : {
                number: inputValue,
                ...this.validateAmount(inputValue)
            }
        });
    }

    handleStockChange(event) {
        const target = event.target;
        const inputName = target.name;        
        const inputValue = target.value;
        console.log(inputName+"--"+inputValue)
        this.setState({
            [inputName] : {
                number: inputValue,
                ...this.validateAmount(inputValue)
            }
        });
    }

    handleCategoryIdChange(input) {
        this.setState({
            category: input
        });
        console.log(input.label)
        this.setState({
            categoryId: {
                text: input.key,
                ...this.validateCategoryId(input.key)
            }
        });
        this.setState({
            categoryName: {
                text: input.label,
                ...this.validateCategoryName(input.label)
            }
        });``
        this.setState({
            subCategories: []
        }); 
        this.loadSubCategoriesList(input.key)
    }

    
    handleSubCategoryIdChange(input) {
        this.setState({
            subCategory: input
        });
        console.log(input.label)
        this.setState({
            subCategoryId: {
                text: input.key,
                ...this.validateCategoryId(input.key)
            }
        });
        this.setState({
            subCategoryName: {
                text: input.label,
                ...this.validateCategoryName(input.label)
            }
        });``
    }

    validateCategoryId = (text) => {
        if(text === 0) {
            return {
                validateStatus: 'error',
                errorMsg: 'Please Select a Category!'
            }
        } else {
            return {
                validateStatus: 'success',
                errorMsg: null
            }
        }
    }

    validateCategoryName = (text) => {
        console.log(text)
        console.log(text === 0)
        if(text === 0) {
            return {
                validateStatus: 'error',
                errorMsg: 'Please Select a Category!'
            }
        } else {
            return {
                validateStatus: 'success',
                errorMsg: null
            }
        }
    }
    

    isFormInvalid() {

        if(this.state.productCode.validateStatus !== 'success') {
            return true;
        } 
        if(this.state.productName.validateStatus !== 'success') {
            return true;
        }
        if(this.state.description.validateStatus !== 'success') {
            return true;
        }
        if(this.state.categoryId.validateStatus !== 'success') {
            return true;
        }
        if(this.state.subCategoryId.validateStatus !== 'success') {
            return true;
        }
        if(this.state.price.validateStatus !== 'success') {
            return true;
        }
        if(this.state.brand.validateStatus !== 'success') {
            return true;
        }
        if(this.state.stock.validateStatus !== 'success') {
            return true;
        }
    }

    render() {
        const layout = {
            labelCol: { span: 8 },
            wrapperCol: { span: 16 },
          };
          const tailLayout = {
            wrapperCol: { offset: 8, span: 16 },
          };

          const { categories } = this.state;
          const { subCategories } = this.state;

          let categoryList = categories.length > 0
          && categories.map((item, i) => {
          return (
              <Option key={i} value={item.id}>{item.name}</Option>
          )
        }, this);

          
          let subCategoryList = subCategories.length > 0
          && subCategories.map((item, i) => {
          return (
              <Option key={i} value={item.id}>{item.name}</Option>
          )
        }, this);

        const uploadProps = {
            name: 'file',
            headers: {
              authorization: 'authorization-text',
            },
            onChange(info) {
              if (info.file.status !== 'uploading') {
                console.log(info.file, info.fileList);
              }
              if (info.file.status === 'done') {
                notification.success(`${info.file.name} file uploaded successfully`);
              } else if (info.file.status === 'error') {
                notification.error(`${info.file.name} file upload failed.`);
              }
            },
          };

        return (
            <div className="new-product-container">
                <h1 className="page-title">Create product</h1>
                <div className="new-product-content">
                    <Form {...layout} onSubmit={this.handleSubmit} className="create-product-form">

                        <FormItem validateStatus={this.state.productCode.validateStatus}  label="Product Code"
                            help={this.state.productCode.errorMsg} className="product-form-row">
                               <Input style = {{ fontSize: '16px' }} type="text" name="name" placeholder="Product Code"   
                                value = {this.state.productCode.text}
                                onChange = {this.handleProductCodeChange} />
                        </FormItem>
                        <FormItem validateStatus={this.state.productName.validateStatus}  label="Name"
                            help={this.state.productName.errorMsg} className="product-form-row">
                               <Input style = {{ fontSize: '16px' }} type="text" name="productName" placeholder="Name"   
                                value = {this.state.productName.text}
                                onChange = {this.handleProductNameChange} />
                        </FormItem>
                        <FormItem validateStatus={this.state.description.validateStatus}  label="Description"
                            help={this.state.description.errorMsg} className="product-form-row">
                               <Input style = {{ fontSize: '16px' }} name="description" placeholder="Description"   
                                value = {this.state.description.text}
                                onChange = {this.handleDescriptionChange} />
                        </FormItem>
                        <FormItem validateStatus={this.state.categoryId.validateStatus}  label="Category"
                            help={this.state.categoryId.errorMsg} className="appointment-form-row">
                                <Select  name="categoryId" labelInValue
                                placeholder="Select a option and change input text above"
                                value={this.state.category} 
                                onChange = {this.handleCategoryIdChange}
                                >
                                {categoryList}
                                </Select>
                        </FormItem>
                        <FormItem validateStatus={this.state.subCategoryId.validateStatus}  label="Sub Category"
                            help={this.state.subCategoryId.errorMsg} className="appointment-form-row">
                                <Select  name="subCategoryId" labelInValue
                                placeholder="Select a option and change input text above"
                                value={this.state.subCategory} 
                                onChange = {this.handleSubCategoryIdChange}
                                >
                                {subCategoryList}
                                </Select>
                        </FormItem>
                        
                        <FormItem validateStatus={this.state.price.validateStatus} label="Price"
                            help={this.state.price.errorMsg} className="patient-form-row">
                               <Input style = {{ fontSize: '16px' }} name="price" placeholder="Price"   
                                value = {this.state.price.number} 
                                onChange = {this.handlePriceChange} />
                        </FormItem>
                        <FormItem validateStatus={this.state.brand.validateStatus} label="Brand"
                            help={this.state.brand.errorMsg} className="patient-form-row">
                               <Input style = {{ fontSize: '16px' }} name="brand" placeholder="Brand"   
                                value = {this.state.brand.text} 
                                onChange = {this.handleBrandChange} />
                        </FormItem>
                        <FormItem validateStatus={this.state.stock.validateStatus} label="Stock"
                            help={this.state.stock.errorMsg} className="patient-form-row">
                               <Input style = {{ fontSize: '16px' }} name="stock" placeholder="Stock"   
                                value = {this.state.stock.number}  pattern="[0-9]*"
                                onChange = {this.handleStockChange} />
                        </FormItem>
                        <FormItem label="Upload">
                                <Upload {...uploadProps}
                                 name="logo"
                                multiple={false}
                                beforeUpload={file => {
                                    const reader = new FileReader();
                                    reader.onload = e => {
                                        this.setState({
                                            image: {
                                                text: e.target.result,
                                            }
                                        })
                                    };
                                    reader.readAsDataURL(file);
                                    return false;
                                }}
                                 listType="picture">
                                <Button>
                                    <Icon type="upload" /> Click to upload
                                </Button>
                                </Upload>
                            </FormItem>
                        <FormItem {...tailLayout}  className="product-form-row">
                            <Button type="primary" 
                                htmlType="submit" 
                                size="large" 
                                disabled={this.isFormInvalid()}
                                className="create-product-form-button">Create product</Button>
                        </FormItem>
                    </Form>
                </div>    
            </div>
        );
    }
}

export default NewProduct;