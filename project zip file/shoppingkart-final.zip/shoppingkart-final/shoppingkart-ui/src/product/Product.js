import React, { Component } from 'react';
import './Product.css';
import {Modal, Table } from 'antd';
import { deleteProduct } from '../util/APIUtils';
const { confirm } = Modal;

class Product extends Component {
  constructor(props) {
    super(props);
    this.state = {
        products: []
    };
    this.showConfirm = this.showConfirm.bind(this);
}

    showConfirm(id,productId) {
      confirm({
        title: 'Do you want to delete product?',
        content: 'When clicked the OK button, this product ( ' + productId+ ' ) will get deleted',
        onOk() {
          let promise;
          promise = deleteProduct(id);
          if(!promise) {
            console.log(promise)
              return;
          }
          promise            
          .then(response => {
              console.log(response);
              alert("product deleted sucessfully");
             window.location ="/";
          }).catch(error => {
            console.log(error)
          });  
        },
        onCancel() {},
      });
    }

    render() {
        const columns = [
          {
            title: 'Product Code',
            dataIndex: 'productCode',
            key: 'productCode',
          },{
              title: 'product Name',
              dataIndex: 'name',
              key: 'name',
            },
            {
              title: 'Description',
              dataIndex: 'description',
              key: 'description',
            },
            {
              title: 'Category',
              dataIndex: 'category',
              key: 'category',
            },
            {
              title: 'Subcategory',
              dataIndex: 'subCategory',
              key: 'subCategory',
            },
            {
              title: 'Price',
              dataIndex: 'price',
              key: 'price',
            },{
              title: 'Brand',
              dataIndex: 'brand',
              key: 'brand',
            },
            {
              title: 'Stock',
              dataIndex: 'stock',
              key: 'stock',
            // },
            // {
            //   title: 'Action',
            //   dataIndex: '',
            //   key: 'id',
            //   render: (text,record) => <Button onClick={() => this.showConfirm(record.id,record.name)} size="small" style={{ width: 90 }}>
            //   Delete
            // </Button>,
            }
          ];

        return (
          <div>

            <Table columns={columns} dataSource={this.props.product} />
            
          </div>
            
        );
    }
}

export default Product;