import React, { Component } from 'react';
import { getAllProducts } from '../util/APIUtils';
import Product from './Product';
import { withRouter } from 'react-router-dom';
import './ProductList.css';

class ProductList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            products: []
        };
        this.loadproductList = this.loadproductList.bind(this);
    }

    loadproductList() {
        let promise;
        promise = getAllProducts();
        if(!promise) {
            return;
        }
        this.setState({
            isLoading: true
        });
        promise            
        .then(response => {
            console.log(response);
            const products = this.state.products.slice();
            this.setState({
                products: products.concat(response),
                isLoading: false
            })
        }).catch(error => {
            if(error.status==401){
                this.props.handleLogout();
              }
        });  
        
    }

    componentDidMount() {
        this.loadproductList();
    }

    componentDidUpdate(nextProps) {
        if(this.props.isAuthenticated !== nextProps.isAuthenticated) {
            // Reset State
            this.setState({
                products: [],
                isLoading: false
            });    
            this.loadproductList();
        }
    }


    render() {
        return (
            <div className="policies-container">
                <h3>Product List</h3>
                <Product product={this.state.products} />
                {
                    !this.state.isLoading && this.state.products.length === 0 ? (
                        <div className="no-products-found">
                            <span>No Products Found.</span>
                        </div>    
                    ): null
                }              
                
            </div>
        );
    }
}

export default withRouter(ProductList);